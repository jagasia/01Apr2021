import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  likeCount:number;  
  title = 'second-project';
  status="danger";
  branches:any;
  constructor()
  {
    this.likeCount=0;
  }
  fnLike()
  {
    this.likeCount++;
  }

  fnUnlike()
  {
    this.likeCount--;
  }

  fnRefresh(branches)
  {
    alert("refreshing..."+branches)
    this.branches=branches;
  }
}
