import { Component, EventEmitter, OnInit, Output } from '@angular/core';


@Component({
  selector: 'app-unlike',
  templateUrl: './unlike.component.html',
  styleUrls: ['./unlike.component.css']
})
export class UnlikeComponent implements OnInit {
  @Output() unLikeEvent:EventEmitter<string>=new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }

  fnUnlike()
  {
    this.unLikeEvent.emit('');
  }
}
