import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-like',
  templateUrl: './like.component.html',
  styleUrls: ['./like.component.css']
})
export class LikeComponent implements OnInit {

  @Output() likeEvent:EventEmitter<string>=new EventEmitter();
  
  constructor() { }

  ngOnInit(): void {
  }

  fn1()
  {
    // alert('you clicked this like button now')
    this.likeEvent.emit('');
  }

 
}
