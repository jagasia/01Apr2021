import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LikeComponent } from './like/like.component';
import { UnlikeComponent } from './unlike/unlike.component';
import { SquarePipe } from './square.pipe';
import { ReactiveFormsModule } from '@angular/forms';
import { BranchComponent } from './branch/branch.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    LikeComponent,
    UnlikeComponent,
    SquarePipe,
    BranchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
